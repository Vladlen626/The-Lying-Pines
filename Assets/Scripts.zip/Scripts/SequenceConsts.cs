﻿namespace _Main.Scripts
{
	public static class SequenceConsts
	{
		public const string FirstSequenceId = "void_place";
		public const string NextSequence = "next_sequence";
	}
}