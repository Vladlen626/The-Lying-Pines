using PlatformCore.Services.UI;

public class UIPlayerCrosshair : BaseUIElement
{
}