﻿namespace _Main.Scripts.Home
{
	public enum HomeState
	{
		Broken = 0,
		Built = 1 
	}
}