﻿namespace _Main.Scripts.Collectibles
{
	public enum CollectibleKind
	{
		Crumb = 0, 
		Croissant = 1,
		Baguette = 2
	}
}