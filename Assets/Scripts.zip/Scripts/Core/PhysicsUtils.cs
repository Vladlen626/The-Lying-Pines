﻿namespace _Main.Scripts
{
	public static class PhysicsUtils
	{
		public const float gravity = -9.8f;
	}
}