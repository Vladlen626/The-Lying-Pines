﻿using System;
using _Main.Scripts.Home;

[Serializable]
public struct HomeSlot
{
	public HomeView Home;
	public CockroachView Builder;
	public int CrumbsCost;
}