﻿namespace PlatformCore.Services
{
	public class SceneNames
	{
		public const string Hub = "hub";
		public const string ExtractionScene = "ExtractionScene";
		public const string Test = "ToDandWeather_Example";
	}
}