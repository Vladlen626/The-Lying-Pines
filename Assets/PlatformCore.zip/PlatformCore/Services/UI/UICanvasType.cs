﻿namespace PlatformCore.Services.UI
{
	public enum UICanvasType
	{
		Static = 0,
		Dynamic = 1,
	}
}