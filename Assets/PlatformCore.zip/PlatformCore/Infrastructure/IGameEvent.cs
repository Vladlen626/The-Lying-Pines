﻿namespace PlatformCore.Infrastructure
{
	public interface IGameEvent {}
}