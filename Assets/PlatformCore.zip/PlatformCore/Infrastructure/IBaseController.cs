﻿namespace PlatformCore.Core
{
	public interface IBaseController
	{
	}
}